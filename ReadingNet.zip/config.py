DB_USER = 'readingNet280'
DB_NAME = 'readingNet'
DB_PASSWORD = ''
DB_HOST = 'localhost'

APP_HOST = '127.0.0.1'
APP_PORT = 5000
APP_DEBUG = True